﻿using HospitalMS.Models;

namespace HospitalMS.Repository
{
    public interface IPatientRepository
    {
        public Patient GetById(int id);

        public List<Patient> GetAll();

        public List<Patient> GetAllPatientByDocId(int DocId);


        public void Save();

    }
}
